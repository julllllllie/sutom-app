<?php

//src/Controller/GameController.php

namespace App\Controller;

use App\Entity\Mots;
use App\Entity\EssaiMot;
use App\Form\GameType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class GameController extends AbstractController
{

} 
